# 📋 ARCHIVOS NECESARIOS PARA COPIAR A LA USB

## ✅ ESTRUCTURA RECOMENDADA EN USB

```
USB/
├── elverproyecto/
│   ├── ARCHIVOS PYTHON (OBLIGATORIOS)
│   ├── ARCHIVOS DE CONFIGURACIÓN
│   ├── ARCHIVOS DE BD
│   ├── ARCHIVOS DE RECURSOS
│   ├── DOCUMENTACIÓN
│   └── requirements.txt
```

---

## 🔴 ARCHIVOS OBLIGATORIOS - COPIAR EN USB

### 1️⃣ ARCHIVOS PYTHON PRINCIPALES (7 archivos)
```
✅ main.py                    # Programa principal - DEBE ESTAR
✅ conexion.py                # Conexión a BD
✅ logica.py                  # Lógica de negocios (ACTUALIZADO con instructores)
✅ admin_panel.py             # Panel administrador (ACTUALIZADO con PantallaInstructor)
✅ dashboard_password.py      # Panel del aprendiz
✅ reportes.py                # Generador de reportes
✅ validadores.py             # Funciones de validación
```

### 2️⃣ ARCHIVOS DE CONFIGURACIÓN (3 archivos)
```
✅ config.py                  # Configuración de colores, fuentes
✅ logging_config.py          # Configuración de logs
✅ ui_helper.py               # Funciones auxiliares de UI
```

### 3️⃣ ARCHIVOS DE ENTORNO (1 archivo)
```
✅ .env                       # Variables de entorno (IMPORTANTE: BD HOST, USER, PASS)
  Contenido:
  DB_HOST=localhost
  DB_USER=root
  DB_PASSWORD=
  DB_NAME=TechSenaHSGS
```

### 4️⃣ BASE DE DATOS (1 archivo SQL)
```
✅ techsenahsgs.sql           # Script completo de BD con:
                              # - Tablas originales
                              # - Tablas nuevas (instructores, fichas_asignadas, faltas)
                              # - Datos de ejemplo
```

### 5️⃣ DEPENDENCIAS (1 archivo)
```
✅ requirements.txt           # Lista de paquetes Python
  Contenido:
  mysql-connector-python
  pandas
  tkcalendar
  openpyxl
  customtkinter
  reportlab
  python-dotenv
  Pillow
```

### 6️⃣ RECURSOS MULTIMEDIA (3 archivos en carpeta images/)
```
✅ images/fondo.jpg           # Fondo de pantalla
✅ images/logosena.png        # Logo del SENA
✅ images/WhatsApp Image...   # Imagen adicional
```

### 7️⃣ DOCUMENTACIÓN (OPCIONAL pero recomendado)
```
📄 README.md                  # Descripción del proyecto
📄 SISTEMA_INSTRUCTORES.md    # Doc del sistema nuevo de instructores
📄 DIAGRAMAS_UML.md           # Diagramas UML
📄 HISTORIAS_DE_USUARIO.md    # Historias de usuario
```

---

## 📊 RESUMEN DE ARCHIVOS

### TOTAL: 25 archivos

| Categoría | Cantidad | Críticos |
|-----------|----------|----------|
| Python (.py) | 10 | ✅ Sí |
| Configuración | 3 | ✅ Sí |
| .env | 1 | ✅ Sí |
| SQL | 1 | ✅ Sí |
| requirements.txt | 1 | ✅ Sí |
| Imágenes | 3 | ✅ Sí |
| Documentación | 6 | ❌ Opcional |
| **TOTAL** | **25** | - |

---

## 🚀 PASOS PARA COPIAR A USB

### 1. CREAR ESTRUCTURA EN USB
```
1. Inserta USB
2. Crea carpeta: USB/elverproyecto/
3. Dentro crea: USB/elverproyecto/images/
```

### 2. COPIAR ARCHIVOS .PY
Copia estos 10 archivos a `USB/elverproyecto/`:
- main.py
- conexion.py
- logica.py
- admin_panel.py
- dashboard_password.py
- reportes.py
- validadores.py
- config.py
- logging_config.py
- ui_helper.py

### 3. COPIAR ARCHIVOS DE CONFIGURACIÓN
Copia a `USB/elverproyecto/`:
- .env
- requirements.txt
- techsenahsgs.sql

### 4. COPIAR IMÁGENES
Copia estos 3 archivos a `USB/elverproyecto/images/`:
- fondo.jpg
- logosena.png
- WhatsApp Image 2026-03-04 at 4.47.18 PM.jpeg

### 5. COPIAR DOCUMENTACIÓN (OPCIONAL)
```
USB/elverproyecto/
├── README.md
├── SISTEMA_INSTRUCTORES.md
├── DIAGRAMAS_UML.md
└── HISTORIAS_DE_USUARIO.md
```

---

## ⚙️ PROCEDIMIENTO DE INSTALACIÓN EN NUEVA MÁQUINA

### En la máquina destino:

1. **Copiar archivos de USB a carpeta local**
   ```
   C:\Users\[Usuario]\Documents\elverproyecto\
   ```

2. **Instalar Python 3.10+ (si no lo tiene)**
   - Descargar de python.org
   - IMPORTANTE: Marcar "Add Python to PATH"

3. **Instalar dependencias**
   ```powershell
   cd C:\Users\[Usuario]\Documents\elverproyecto
   pip install -r requirements.txt
   ```

4. **Configurar BD**
   - Instalar MySQL Server 8.0+
   - Ejecutar script SQL:
     ```
     mysql -u root -p < techsenahsgs.sql
     ```
   - Verificar en `.env`:
     ```
     DB_HOST=localhost
     DB_USER=root
     DB_PASSWORD=[tu_password]
     DB_NAME=TechSenaHSGS
     ```

5. **Ejecutar programa**
   ```powershell
   python main.py
   ```

---

## 🔐 CREDENCIALES POR DEFECTO

Después de ejecutar el SQL:

| Tipo Usuario | Usuario | Contraseña |
|---|---|---|
| **Admin** | admin | admin123 |
| **Aprendiz** | 1010101 | pass123 |
| **Instructor** | instructor1* | sena123 |

*Debe crear instructor en BD primero

---

## ⚠️ IMPORTANTE - ARCHIVOS QUE NO DEBEN COPIARSE

❌ NO copiar:
- `__pycache__/` (carpeta de cache)
- `*.pyc` (compilados)
- `crs.log` (archivo de logs actual)
- `.vscode/` (configuración del editor)
- `test_*.py` (archivos de prueba)
- `.env.example` (usar .env en su lugar)

---

## 📝 CHECKLIST FINAL

Antes de usar la USB en otra máquina, verificar:

- [ ] ✅ Todos los .py están presentes (10 archivos)
- [ ] ✅ .env configurado correctamente
- [ ] ✅ requirements.txt copiado
- [ ] ✅ techsenahsgs.sql presente
- [ ] ✅ Carpeta images/ con 3 archivos
- [ ] ✅ Documentación copiada (opcional)
- [ ] ✅ NO hay archivos innecesarios (__pycache__, .pyc, etc)

---

## 💾 ESPACIO NECESARIO EN USB

- Archivos .py: ~500 KB
- Imágenes: ~2-3 MB
- BD SQL: ~100 KB
- Documentación: ~300 KB
- **TOTAL: ~4 MB**

**Recomendación**: USB de 32 GB mínimo (para tener espacio para BD y logs futuros)

---

## 🆘 SI ALGO NO FUNCIONA

1. Verificar que Python 3.10+ está instalado
2. Verificar que MySQL está corriendo
3. Verificar que .env tiene datos correctos de BD
4. Ver archivo `crs.log` para errores
5. Ejecutar: `pip install --upgrade -r requirements.txt`

---

**Versión: 1.0 - Sistema con Instructores + Registro de Faltas**
**Fecha: 5 de marzo de 2026**
